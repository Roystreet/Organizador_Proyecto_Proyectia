import 'server-only';
import { fila } from '@/db';
import {
  proyectoPorId, tareasDeProyecto, asuntosDeProyecto, equipoDeProyecto,
  tendenciaDeProyecto, eventosDeProyecto, decisionesDeProyecto,
  habilidadesRequeridas, patronesActivos, filasRecomendacionesPrevias,
} from './consultasIa';
import { ProyectoNoEncontrado } from './errores';
import type {
  PayloadSaludProyecto, MetaPayload, ContextoOrganizacion,
  MetricasTareas, MetricasAsuntos, MetricasActividad, EstadoTarea, Prioridad,
} from './tipos';

export const CONTRATO = 'v1';

/** Topes por sección. Ver docs/03-contrato-ia.md § presupuesto de tamaño. */
const TOPES = { tareas: 15, asuntos: 15, eventos: 30, decisiones: 10, tendencia: 12 };

const hoyISO = () => new Date().toISOString().slice(0, 10);

const meta = (tipo: MetaPayload['tipo_analisis'], ventana = 30): MetaPayload => ({
  contrato: CONTRATO,
  tipo_analisis: tipo,
  fecha_referencia: hoyISO(),
  zona_horaria: 'America/Caracas',
  ventana_dias: ventana,
  idioma_respuesta: 'es',
});

async function contextoOrganizacion(): Promise<ContextoOrganizacion> {
  const r = await fila<{ proyectos_activos: number; personas_activas: number; capacidad: number | null }>(`
    SELECT
      (SELECT COUNT(*) FROM proyectos WHERE archivado = 0
         AND estado NOT IN ('completado','cancelado'))                     AS proyectos_activos,
      (SELECT COUNT(*) FROM personas WHERE activo = 1)                     AS personas_activas,
      (SELECT SUM(disponibilidad_horas_semana) FROM personas
        WHERE activo = 1 AND tipo_relacion IN ('interno','freelance'))     AS capacidad
  `);
  return {
    nombre: process.env.ORG_NOMBRE ?? 'Verde Studio',
    proyectos_activos: r?.proyectos_activos ?? 0,
    personas_activas: r?.personas_activas ?? 0,
    capacidad_semanal_horas: r?.capacidad ?? null,
    prioridades_declaradas: [],
  };
}

const listaIds = (v: string | null): number[] =>
  v ? v.split(',').map(Number).filter((n) => !Number.isNaN(n)) : [];

/**
 * Arma el payload de `salud_proyecto`.
 *
 * Todo lo contable ya viene contado desde SQL. Aquí solo se ensambla y se
 * recorta a los topes. El objeto resultante es determinista para un mismo
 * estado de la base: dos llamadas seguidas producen el mismo hash y la segunda
 * sale de caché.
 */
export async function payloadSaludProyecto(proyectoId: number): Promise<PayloadSaludProyecto> {
  const p = await proyectoPorId(proyectoId);
  if (!p) throw new ProyectoNoEncontrado(proyectoId);

  const [
    tareas, asuntos, equipo, tendencia, eventos, decisiones, skills,
    patrones, previas, mt, ma, act,
  ] = await Promise.all([
    tareasDeProyecto(proyectoId),
    asuntosDeProyecto(proyectoId),
    equipoDeProyecto(proyectoId),
    tendenciaDeProyecto(proyectoId),
    eventosDeProyecto(proyectoId, TOPES.eventos),
    decisionesDeProyecto(proyectoId),
    habilidadesRequeridas(proyectoId),
    patronesActivos(),
    filasRecomendacionesPrevias(proyectoId),
    metricasTareas(proyectoId),
    metricasAsuntos(proyectoId),
    metricasActividad(proyectoId),
  ]);

  const abiertas = tareas.filter((t) => !['completada', 'cancelada'].includes(t.estado));

  return {
    meta: meta('salud_proyecto'),
    organizacion: await contextoOrganizacion(),
    proyecto: {
      id: p.id,
      codigo: p.codigo,
      nombre: p.nombre,
      categoria: p.categoria,
      etiquetas: [],
      cliente: p.empresa ? { id: 0, nombre: p.empresa, industria: null } : null,
      estado: p.estado,
      prioridad: p.prioridad,
      salud_actual: p.salud,
      objetivo: p.objetivo,
      descripcion: p.descripcion,

      fechas: {
        inicio: p.fecha_inicio,
        fin_estimada: p.fecha_fin_estimada,
        dias_transcurridos: diasEntre(p.fecha_inicio, hoyISO()),
        dias_restantes: p.dias_restantes,
        tiempo_consumido_pct: tiempoConsumido(p.fecha_inicio, p.fecha_fin_estimada),
      },

      progreso: {
        declarado_pct: p.progreso_pct,
        calculado_pct: p.tareas_total > 0
          ? Math.round((p.tareas_completadas / p.tareas_total) * 100)
          : 0,
        desviacion_pct: desviacion(p),
      },

      metricas: { tareas: mt, asuntos: ma, actividad: act },

      equipo: equipo.map((m) => ({
        persona_id: m.persona_id,
        nombre: m.nombre,
        rol: m.rol,
        seniority: m.seniority,
        asignacion_pct: m.asignacion_pct,
        fortalezas: m.fortalezas ? m.fortalezas.split(', ') : [],
        tareas_abiertas: m.tareas_abiertas,
        tareas_vencidas: m.tareas_vencidas,
        tareas_bloqueadas: m.tareas_bloqueadas,
        carga_total_proyectos: m.carga_total_proyectos,
        horas_comprometidas: m.horas_comprometidas,
        disponibilidad_horas_semana: m.disponibilidad_horas_semana,
      })),

      habilidades_requeridas: skills.map((s) => ({
        nombre: s.nombre,
        nivel_minimo: s.nivel_minimo,
        criticidad: s.criticidad,
        cubierta: Boolean(s.cubierta),
      })),

      tareas_criticas: abiertas.slice(0, TOPES.tareas).map((t) => ({
        id: t.id,
        titulo: t.titulo,
        estado: t.estado,
        prioridad: t.prioridad,
        tipo: t.tipo,
        responsable_id: t.responsable_id,
        responsable: t.responsable,
        dias_para_vencer: t.dias_para_vencer,
        dias_en_estado_actual: t.dias_en_estado_actual,
        motivo_bloqueo: t.motivo_bloqueo,
        bloquea_a: listaIds(t.bloquea_a),
        depende_de: listaIds(t.depende_de),
      })),

      asuntos_abiertos: asuntos
        .filter((a) => !['resuelto', 'cerrado', 'descartado'].includes(a.estado))
        .slice(0, TOPES.asuntos)
        .map((a) => ({
          id: a.id,
          codigo: a.codigo,
          titulo: a.titulo,
          tipo: a.tipo,
          categoria: a.categoria,
          severidad: a.severidad,
          impacto: a.impacto,
          estado: a.estado,
          asignado_a_id: a.asignado_a_id,
          dias_abierto: a.dias_abierto,
          es_recurrente: Boolean(a.es_recurrente),
          causa_raiz: a.causa_raiz,
        })),

      hitos: await hitosDeProyecto(proyectoId),
      eventos_recientes: eventos,
      decisiones: decisiones.slice(0, TOPES.decisiones),
      tendencia: tendencia.slice(0, TOPES.tendencia).reverse(),
    },
    patrones_conocidos: patrones.map((x) => ({
      clave: x.clave,
      nombre: x.nombre,
      tipo: x.tipo,
      frecuencia: x.frecuencia,
      confianza: x.confianza,
      ultima_deteccion: String(x.ultima_deteccion).slice(0, 10),
    })),
    recomendaciones_previas: previas,
  };
}

/* -------------------------------------------------------------------------- */
/*  Métricas agregadas                                                         */
/* -------------------------------------------------------------------------- */

async function metricasTareas(id: number): Promise<MetricasTareas> {
  const r = await fila<Record<string, number | null>>(
    `SELECT
       COUNT(*)                                                                   AS total,
       SUM(estado='pendiente')    AS pendiente,  SUM(estado='en_progreso') AS en_progreso,
       SUM(estado='en_revision')  AS en_revision, SUM(estado='bloqueada')  AS bloqueada,
       SUM(estado='completada')   AS completada, SUM(estado='cancelada')   AS cancelada,
       SUM(estado NOT IN ('completada','cancelada') AND fecha_vencimiento < CURDATE()) AS vencidas,
       SUM(estado NOT IN ('completada','cancelada') AND responsable_id IS NULL)        AS sin_responsable,
       SUM(estado='completada' AND fecha_completada >= DATE_SUB(NOW(), INTERVAL 14 DAY)) AS compl_14d,
       SUM(creado_en >= DATE_SUB(NOW(), INTERVAL 14 DAY))                          AS creadas_14d,
       AVG(CASE WHEN estado='completada' AND fecha_completada IS NOT NULL
                THEN DATEDIFF(fecha_completada, creado_en) END)                    AS ciclo,
       SUM(CASE WHEN estado NOT IN ('completada','cancelada') THEN estimacion_horas END) AS horas
     FROM tareas WHERE proyecto_id = ?`,
    [id],
  );
  const n = (k: string) => Number(r?.[k] ?? 0);
  return {
    total: n('total'),
    por_estado: {
      pendiente: n('pendiente'), en_progreso: n('en_progreso'), en_revision: n('en_revision'),
      bloqueada: n('bloqueada'), completada: n('completada'), cancelada: n('cancelada'),
    } as Record<EstadoTarea, number>,
    bloqueadas: n('bloqueada'),
    vencidas: n('vencidas'),
    sin_responsable: n('sin_responsable'),
    completadas_ultimos_14d: n('compl_14d'),
    creadas_ultimos_14d: n('creadas_14d'),
    ciclo_promedio_dias: r?.ciclo != null ? Math.round(Number(r.ciclo)) : null,
    horas_estimadas_pendientes: r?.horas != null ? Number(r.horas) : null,
  };
}

async function metricasAsuntos(id: number): Promise<MetricasAsuntos> {
  const abierto = `estado NOT IN ('resuelto','cerrado','descartado')`;
  const r = await fila<Record<string, number | null>>(
    `SELECT
       SUM(${abierto})                                        AS abiertos,
       SUM(${abierto} AND severidad='baja')                   AS baja,
       SUM(${abierto} AND severidad='media')                  AS media,
       SUM(${abierto} AND severidad='alta')                   AS alta,
       SUM(${abierto} AND severidad='critica')                AS critica,
       SUM(${abierto} AND es_recurrente=1)                    AS recurrentes,
       AVG(CASE WHEN ${abierto} THEN DATEDIFF(CURDATE(), DATE(fecha_reporte)) END) AS edad,
       AVG(CASE WHEN fecha_resolucion IS NOT NULL
                THEN DATEDIFF(fecha_resolucion, fecha_reporte) END)                AS resol
     FROM asuntos WHERE proyecto_id = ?`,
    [id],
  );
  const cats = await import('@/db').then(({ filas }) => filas<{ categoria: string; total: number }>(
    `SELECT COALESCE(ca.nombre,'Sin categoría') AS categoria, COUNT(*) AS total
       FROM asuntos a LEFT JOIN categorias_asunto ca ON ca.id = a.categoria_asunto_id
      WHERE a.proyecto_id = ? AND a.${abierto}
      GROUP BY categoria`, [id]));
  const n = (k: string) => Number(r?.[k] ?? 0);
  return {
    abiertos: n('abiertos'),
    por_severidad: { baja: n('baja'), media: n('media'), alta: n('alta'), critica: n('critica') } as Record<Prioridad, number>,
    por_categoria: Object.fromEntries(cats.map((c) => [c.categoria, Number(c.total)])),
    criticos_abiertos: n('critica'),
    recurrentes: n('recurrentes'),
    edad_promedio_dias: r?.edad != null ? Math.round(Number(r.edad)) : null,
    resolucion_promedio_dias: r?.resol != null ? Math.round(Number(r.resol)) : null,
  };
}

async function metricasActividad(id: number): Promise<MetricasActividad> {
  const r = await fila<Record<string, number | null>>(
    `SELECT
       DATEDIFF(CURDATE(), DATE(COALESCE(p.ultimo_movimiento_en, p.creado_en)))  AS dias_sin_mov,
       (SELECT COUNT(*) FROM bitacora b WHERE b.proyecto_id = p.id
          AND b.creado_en >= DATE_SUB(NOW(), INTERVAL 7 DAY))                    AS e7,
       (SELECT COUNT(*) FROM bitacora b WHERE b.proyecto_id = p.id
          AND b.creado_en >= DATE_SUB(NOW(), INTERVAL 30 DAY))                   AS e30,
       (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id
          AND t.estado='completada'
          AND t.fecha_completada >= DATE_SUB(NOW(), INTERVAL 28 DAY))            AS compl_28d,
       (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id
          AND t.estado='completada'
          AND t.fecha_completada >= DATE_SUB(NOW(), INTERVAL 56 DAY)
          AND t.fecha_completada <  DATE_SUB(NOW(), INTERVAL 28 DAY))            AS compl_prev
     FROM proyectos p WHERE p.id = ?`,
    [id],
  );
  const c28 = Number(r?.compl_28d ?? 0);
  const cPrev = Number(r?.compl_prev ?? 0);
  const velocidad = c28 / 4;

  let tendencia: MetricasActividad['tendencia_velocidad'] = 'sin_datos';
  if (c28 + cPrev > 0) {
    if (c28 > cPrev) tendencia = 'sube';
    else if (c28 < cPrev) tendencia = 'baja';
    else tendencia = 'estable';
  }

  return {
    dias_sin_movimiento: Number(r?.dias_sin_mov ?? 0),
    eventos_ultimos_7d: Number(r?.e7 ?? 0),
    eventos_ultimos_30d: Number(r?.e30 ?? 0),
    velocidad_semanal: c28 > 0 ? Number(velocidad.toFixed(2)) : 0,
    tendencia_velocidad: tendencia,
  };
}

async function hitosDeProyecto(id: number) {
  const { filas } = await import('@/db');
  return filas<{ id: number; nombre: string; fecha_objetivo: string | null; dias_para_objetivo: number | null; estado: string; tareas_pendientes: number }>(
    `SELECT h.id, h.nombre, h.fecha_objetivo,
            DATEDIFF(h.fecha_objetivo, CURDATE()) AS dias_para_objetivo, h.estado,
            (SELECT COUNT(*) FROM tareas t WHERE t.hito_id = h.id
               AND t.estado NOT IN ('completada','cancelada')) AS tareas_pendientes
       FROM hitos h WHERE h.proyecto_id = ? AND h.estado <> 'cancelado'
      ORDER BY h.orden, h.fecha_objetivo`, [id]);
}

/* -------------------------------------------------------------------------- */
/*  Utilidades de fecha                                                        */
/* -------------------------------------------------------------------------- */

function diasEntre(desde: string | null, hasta: string): number | null {
  if (!desde) return null;
  const a = new Date(`${desde}T00:00:00`).getTime();
  const b = new Date(`${hasta}T00:00:00`).getTime();
  return Math.round((b - a) / 86_400_000);
}

function tiempoConsumido(inicio: string | null, fin: string | null): number | null {
  if (!inicio || !fin) return null;
  const total = diasEntre(inicio, fin);
  const corrido = diasEntre(inicio, hoyISO());
  if (total === null || corrido === null || total <= 0) return null;
  return Math.min(100, Math.max(0, Math.round((corrido / total) * 100)));
}

function desviacion(p: { fecha_inicio: string | null; fecha_fin_estimada: string | null; tareas_total: number; tareas_completadas: number }): number | null {
  const t = tiempoConsumido(p.fecha_inicio, p.fecha_fin_estimada);
  if (t === null) return null;
  const avance = p.tareas_total > 0 ? Math.round((p.tareas_completadas / p.tareas_total) * 100) : 0;
  return t - avance;
}
