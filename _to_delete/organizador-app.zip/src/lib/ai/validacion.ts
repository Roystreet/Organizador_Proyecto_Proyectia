/**
 * Validación de lo que devuelve el modelo.
 *
 * Structured Outputs ya garantiza la forma, pero no garantiza los rangos:
 * un puntaje de 140 o una confianza de 3 pasan el esquema JSON y rompen la UI.
 * Zod es la segunda barrera, y además es lo que valida la salida del modo
 * simulado, que no pasa por OpenAI.
 */
import { z } from 'zod';

const PRIORIDAD = z.enum(['baja', 'media', 'alta', 'critica']);
const TRIPLE = z.enum(['bajo', 'medio', 'alto']);
const ENTIDAD = z.enum(['proyecto', 'tarea', 'asunto', 'persona']);

export const zRecomendacion = z.object({
  titulo: z.string().min(3).max(255),
  descripcion: z.string(),
  justificacion: z.string(),
  tipo: z.enum(['accion', 'alerta', 'riesgo', 'mejora', 'asignacion', 'pregunta']),
  prioridad: PRIORIDAD,
  impacto_estimado: TRIPLE,
  esfuerzo_estimado: TRIPLE,
  entidad_tipo: ENTIDAD.nullable(),
  entidad_id: z.number().int().positive().nullable(),
  persona_sugerida_id: z.number().int().positive().nullable(),
  plazo_sugerido_dias: z.number().int().nullable(),
});

export const zRespuestaSaludProyecto = z.object({
  puntaje_salud: z.number().int().min(0).max(100),
  semaforo: z.enum(['verde', 'amarillo', 'rojo']),
  resumen_ejecutivo: z.string().min(10),
  diagnostico: z.array(z.object({
    area: z.enum(['alcance', 'tiempo', 'equipo', 'calidad', 'comunicacion', 'dependencias']),
    hallazgo: z.string(),
    evidencia: z.array(z.string()),
    severidad: TRIPLE,
  })),
  riesgos: z.array(z.object({
    titulo: z.string(),
    descripcion: z.string(),
    probabilidad: TRIPLE,
    impacto: TRIPLE,
    'señales_tempranas': z.array(z.string()),
    mitigacion: z.string(),
  })),
  cuellos_botella: z.array(z.object({
    entidad_tipo: ENTIDAD,
    entidad_id: z.number().int(),
    titulo: z.string(),
    dias_detenido: z.number().int().nullable(),
    por_que_bloquea: z.string(),
    desbloqueo_sugerido: z.string(),
  })),
  recomendaciones: z.array(zRecomendacion),
  plan_mejora: z.object({
    horizonte_dias: z.number().int().positive(),
    pasos: z.array(z.object({
      orden: z.number().int(),
      accion: z.string(),
      responsable_sugerido_id: z.number().int().positive().nullable(),
      resultado_esperado: z.string(),
      dias_estimados: z.number().int().nullable(),
    })),
  }),
  preguntas_para_el_equipo: z.array(z.object({
    persona_id: z.number().int().positive().nullable(),
    pregunta: z.string(),
    motivo: z.string(),
  })),
  confianza: z.number().min(0).max(1),
  datos_faltantes: z.array(z.string()),
});

export type RespuestaSaludValidada = z.infer<typeof zRespuestaSaludProyecto>;

/**
 * Los ids que devuelve el modelo tienen que existir en el payload. Si inventa
 * uno, se anula en vez de guardar una referencia rota que rompería el enlace
 * en la interfaz.
 */
export function sanearReferencias(
  r: RespuestaSaludValidada,
  idsValidos: { tareas: Set<number>; asuntos: Set<number>; personas: Set<number>; proyecto: number },
): { datos: RespuestaSaludValidada; descartadas: number } {
  let descartadas = 0;

  const existe = (tipo: string | null, id: number | null) => {
    if (!tipo || id === null) return false;
    if (tipo === 'proyecto') return id === idsValidos.proyecto;
    if (tipo === 'tarea') return idsValidos.tareas.has(id);
    if (tipo === 'asunto') return idsValidos.asuntos.has(id);
    if (tipo === 'persona') return idsValidos.personas.has(id);
    return false;
  };

  const recomendaciones = r.recomendaciones.map((x) => {
    const ok = existe(x.entidad_tipo, x.entidad_id);
    if (x.entidad_id !== null && !ok) descartadas++;
    return {
      ...x,
      entidad_tipo: ok ? x.entidad_tipo : null,
      entidad_id: ok ? x.entidad_id : null,
      persona_sugerida_id:
        x.persona_sugerida_id && idsValidos.personas.has(x.persona_sugerida_id)
          ? x.persona_sugerida_id
          : null,
    };
  });

  const cuellos = r.cuellos_botella.filter((c) => {
    const ok = existe(c.entidad_tipo, c.entidad_id);
    if (!ok) descartadas++;
    return ok;
  });

  return { datos: { ...r, recomendaciones, cuellos_botella: cuellos }, descartadas };
}
