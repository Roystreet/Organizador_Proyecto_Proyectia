import 'server-only';
import { createHash } from 'node:crypto';
import { pool, filas, fila } from '@/db';
import { payloadSaludProyecto } from './construirPayload';
import { promptSistema, mensajeUsuario, PROMPT_VERSION } from './prompts';
import { formatoRespuesta } from './esquemas';
import { zRespuestaSaludProyecto, sanearReferencias, type RespuestaSaludValidada } from './validacion';
import { simularSaludProyecto } from './simulador';
import type { PayloadSaludProyecto } from './tipos';

export interface ResultadoSalud {
  analisis_id: number;
  /** Ids reales de recomendaciones_ia, en el mismo orden que datos.recomendaciones. */
  recomendacion_ids: number[];
  datos: RespuestaSaludValidada;
  desde_cache: boolean;
  modo: 'real' | 'simulado';
  modelo: string;
  latencia_ms: number;
  referencias_descartadas: number;
}

/** Serialización con claves ordenadas: mismo estado ⇒ mismo hash. */
function estable(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v) ?? 'null';
  if (Array.isArray(v)) return `[${v.map(estable).join(',')}]`;
  const o = v as Record<string, unknown>;
  return `{${Object.keys(o).sort().map((k) => `${JSON.stringify(k)}:${estable(o[k])}`).join(',')}}`;
}

/**
 * Hash del ESTADO DEL PROYECTO, no del payload completo.
 *
 * `recomendaciones_previas` viaja dentro del payload, así que si se incluyera
 * tal cual, cada análisis invalidaría su propia caché al insertar sus
 * recomendaciones: el hash nunca coincidiría y siempre se pagaría de nuevo.
 * Se conservan solo las que el usuario ya tocó (aceptó, descartó, implementó),
 * porque eso sí es información nueva que debe disparar un análisis fresco.
 */
function hashPayload(p: PayloadSaludProyecto): string {
  const paraHash = {
    ...p,
    recomendaciones_previas: p.recomendaciones_previas
      .filter((r) => r.estado !== 'nueva')
      .map(({ id, estado, feedback_usuario }) => ({ id, estado, feedback_usuario })),
  };
  return createHash('sha256').update(estable(paraHash)).digest('hex');
}

export { ProyectoNoEncontrado } from './errores';

/* -------------------------------------------------------------------------- */

export async function analizarSaludProyecto(
  proyectoId: number,
  opciones: { forzar?: boolean } = {},
): Promise<ResultadoSalud> {
  const payload = await payloadSaludProyecto(proyectoId);
  const hash = hashPayload(payload);
  const horasCache = Number(process.env.IA_CACHE_HORAS ?? 6);

  /* 1 · Caché: si nada cambió en el proyecto, no hay nada nuevo que analizar. */
  if (!opciones.forzar) {
    const previo = await fila<{ id: number; respuesta_json: unknown; modelo: string }>(
      `SELECT id, respuesta_json, modelo FROM analisis_ia
        WHERE proyecto_id = ? AND tipo_analisis = 'salud_proyecto'
          AND payload_hash = ? AND estado = 'ok'
          AND creado_en >= DATE_SUB(NOW(), INTERVAL ? HOUR)
        ORDER BY creado_en DESC LIMIT 1`,
      [proyectoId, hash, horasCache],
    );
    if (previo) {
      return {
        analisis_id: previo.id,
        recomendacion_ids: await idsRecomendaciones(previo.id),
        datos: normalizarJson(previo.respuesta_json) as RespuestaSaludValidada,
        desde_cache: true,
        modo: previo.modelo === 'reglas-locales' ? 'simulado' : 'real',
        modelo: previo.modelo,
        latencia_ms: 0,
        referencias_descartadas: 0,
      };
    }
  }

  /* 2 · Análisis */
  const modo: 'real' | 'simulado' =
    process.env.IA_MODO === 'simulado' || !process.env.OPENAI_API_KEY ? 'simulado' : 'real';

  const inicio = Date.now();
  let cruda: unknown;
  let modelo: string;
  let tokensIn: number | null = null;
  let tokensOut: number | null = null;

  if (modo === 'simulado') {
    modelo = 'reglas-locales';
    cruda = simularSaludProyecto(payload);
  } else {
    modelo = process.env.OPENAI_MODEL ?? 'gpt-4.1';
    const { default: OpenAI } = await import('openai');
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const r = await openai.chat.completions.create({
      model: modelo,
      temperature: 0.2,                       // análisis, no creatividad
      messages: [
        { role: 'system', content: promptSistema('salud_proyecto') },
        { role: 'user', content: mensajeUsuario(payload) },
      ],
      response_format: formatoRespuesta('salud_proyecto'),
    });
    const texto = r.choices[0]?.message?.content;
    if (!texto) throw new Error('El modelo devolvió una respuesta vacía');
    cruda = JSON.parse(texto);
    tokensIn = r.usage?.prompt_tokens ?? null;
    tokensOut = r.usage?.completion_tokens ?? null;
  }

  const latencia = Date.now() - inicio;

  /* 3 · Validación de rangos y de referencias */
  const parseo = zRespuestaSaludProyecto.safeParse(cruda);
  if (!parseo.success) {
    await registrarError(proyectoId, payload, hash, modelo, parseo.error.message, latencia);
    throw new Error(`La respuesta del modelo no cumple el contrato: ${parseo.error.issues[0]?.message}`);
  }

  const { datos, descartadas } = sanearReferencias(parseo.data, {
    proyecto: proyectoId,
    tareas: new Set(payload.proyecto.tareas_criticas.map((t) => t.id)),
    asuntos: new Set(payload.proyecto.asuntos_abiertos.map((a) => a.id)),
    personas: new Set(payload.proyecto.equipo.map((e) => e.persona_id)),
  });

  /* 4 · Persistencia transaccional */
  const { analisisId, recomendacionIds } = await guardar(proyectoId, payload, hash, modelo, datos, {
    tokensIn, tokensOut, latencia,
  });

  return {
    analisis_id: analisisId,
    recomendacion_ids: recomendacionIds,
    datos,
    desde_cache: false,
    modo,
    modelo,
    latencia_ms: latencia,
    referencias_descartadas: descartadas,
  };
}

/* -------------------------------------------------------------------------- */

async function guardar(
  proyectoId: number,
  payload: PayloadSaludProyecto,
  hash: string,
  modelo: string,
  datos: RespuestaSaludValidada,
  uso: { tokensIn: number | null; tokensOut: number | null; latencia: number },
): Promise<{ analisisId: number; recomendacionIds: number[] }> {
  const conexion = await pool.getConnection();
  try {
    await conexion.beginTransaction();

    const [res] = await conexion.query(
      `INSERT INTO analisis_ia
         (tipo_analisis, alcance, proyecto_id, modelo, prompt_version, payload_hash,
          payload_json, respuesta_json, resumen, puntaje_salud, estado,
          tokens_entrada, tokens_salida, latencia_ms)
       VALUES ('salud_proyecto','proyecto',?,?,?,?,?,?,?,?,'ok',?,?,?)`,
      [
        proyectoId, modelo, PROMPT_VERSION, hash,
        JSON.stringify(payload), JSON.stringify(datos),
        datos.resumen_ejecutivo, datos.puntaje_salud,
        uso.tokensIn, uso.tokensOut, uso.latencia,
      ],
    );
    const analisisId = (res as { insertId: number }).insertId;

    const recomendacionIds: number[] = [];
    for (const r of datos.recomendaciones) {
      const [ins] = await conexion.query(
        `INSERT INTO recomendaciones_ia
           (analisis_id, proyecto_id, tipo, titulo, descripcion, justificacion, prioridad,
            impacto_estimado, esfuerzo_estimado, entidad_tipo, entidad_id, persona_sugerida_id)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          analisisId, proyectoId, r.tipo, r.titulo, r.descripcion, r.justificacion,
          r.prioridad, r.impacto_estimado, r.esfuerzo_estimado,
          r.entidad_tipo, r.entidad_id, r.persona_sugerida_id,
        ],
      );
      recomendacionIds.push((ins as { insertId: number }).insertId);
    }

    // El semáforo del dashboard pasa a ser el que dictaminó el análisis.
    await conexion.query(
      `UPDATE proyectos SET salud = ?, salud_origen = 'ia' WHERE id = ?`,
      [datos.semaforo, proyectoId],
    );

    await conexion.commit();
    return { analisisId, recomendacionIds };
  } catch (e) {
    await conexion.rollback();
    throw e;
  } finally {
    conexion.release();
  }
}

async function registrarError(
  proyectoId: number, payload: unknown, hash: string,
  modelo: string, mensaje: string, latencia: number,
) {
  await pool.query(
    `INSERT INTO analisis_ia
       (tipo_analisis, alcance, proyecto_id, modelo, prompt_version, payload_hash,
        payload_json, estado, error_mensaje, latencia_ms)
     VALUES ('salud_proyecto','proyecto',?,?,?,?,?,'error',?,?)`,
    [proyectoId, modelo, PROMPT_VERSION, hash, JSON.stringify(payload), mensaje.slice(0, 1000), latencia],
  );
}

/** Ids de las recomendaciones de un análisis, en el orden en que se guardaron. */
export async function idsRecomendaciones(analisisId: number): Promise<number[]> {
  const r = await filas<{ id: number }>(
    `SELECT id FROM recomendaciones_ia WHERE analisis_id = ? ORDER BY id`,
    [analisisId],
  );
  return r.map((x) => x.id);
}

/** MySQL puede devolver JSON como objeto o como string según el driver. */
function normalizarJson(v: unknown): unknown {
  return typeof v === 'string' ? JSON.parse(v) : v;
}

/* -------------------------------------------------------------------------- */
/*  Feedback: lo que cierra el ciclo de aprendizaje                            */
/* -------------------------------------------------------------------------- */

export async function actualizarRecomendacion(
  id: number,
  estado: 'nueva' | 'aceptada' | 'en_progreso' | 'implementada' | 'descartada',
  feedback?: string,
) {
  await pool.query(
    `UPDATE recomendaciones_ia SET estado = ?, feedback_usuario = COALESCE(?, feedback_usuario)
      WHERE id = ?`,
    [estado, feedback ?? null, id],
  );
}

export async function historialAnalisis(proyectoId: number) {
  return filas<{ id: number; puntaje_salud: number | null; modelo: string; creado_en: string }>(
    `SELECT id, puntaje_salud, modelo, creado_en FROM analisis_ia
      WHERE proyecto_id = ? AND estado = 'ok' ORDER BY creado_en DESC LIMIT 10`,
    [proyectoId],
  );
}
