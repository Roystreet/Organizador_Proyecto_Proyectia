import {
  Box, Card, CardContent, Chip, Divider, Stack, Typography, Avatar, Tooltip,
} from '@mui/material';
import { listaPersonas, habilidadesDePersona, insumosDePersona } from '@/lib/consultas';

export const dynamic = 'force-dynamic';

const ICONO_INSUMO: Record<string, string> = {
  fortaleza: 'Fortaleza',
  aporte: 'Puede aportar',
  pregunta_sugerida: 'Preguntarle',
  area_mejora: 'A desarrollar',
  logro: 'Logro',
  interes: 'Interés',
};

const iniciales = (n: string) =>
  n.split(' ').filter(Boolean).slice(0, 2).map((x) => x[0]).join('').toUpperCase();

export default async function Personas() {
  const personas = await listaPersonas();

  const detalle = await Promise.all(
    personas.map(async (p) => ({
      p,
      habilidades: await habilidadesDePersona(p.id),
      insumos: await insumosDePersona(p.id),
    })),
  );

  return (
    <Stack spacing={2.5}>
      <Box>
        <Typography variant="h2">Personas</Typography>
        <Typography color="text.secondary" variant="body2">
          Directorio de involucrados con su experticia y carga actual
        </Typography>
      </Box>

      <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', lg: 'repeat(2, 1fr)' } }}>
        {detalle.map(({ p, habilidades, insumos }) => {
          const fortalezas = habilidades.filter((h) => h.es_fortaleza);
          const otras = habilidades.filter((h) => !h.es_fortaleza);
          const preguntas = insumos.filter((i) => i.tipo === 'pregunta_sugerida');
          const aportes = insumos.filter((i) => i.tipo === 'aporte' || i.tipo === 'fortaleza');

          return (
            <Card key={p.id}>
              <CardContent>
                <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
                  <Avatar sx={{ bgcolor: 'primary.main', width: 42, height: 42, fontSize: '0.9rem', fontWeight: 700 }}>
                    {iniciales(p.nombre_completo)}
                  </Avatar>
                  <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                    <Typography sx={{ fontWeight: 700 }}>{p.nombre_completo}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {[p.rol_principal, p.seniority?.replace('_', ' '),
                        p.anios_experiencia && `${p.anios_experiencia} años`,
                        p.empresa].filter(Boolean).join(' · ')}
                    </Typography>
                  </Box>
                  <Stack spacing={0.5} sx={{ alignItems: 'flex-end' }}>
                    <Chip size="small" variant="outlined" label={p.tipo_relacion} />
                    <Tooltip title="Proyectos activos · tareas abiertas">
                      <Typography variant="caption" color="text.secondary">
                        {p.proyectos_activos} proy · {p.tareas_abiertas} tareas
                      </Typography>
                    </Tooltip>
                  </Stack>
                </Box>

                {fortalezas.length > 0 && (
                  <Box sx={{ mt: 1.5 }}>
                    <Typography variant="overline" color="text.secondary">Fuerte en</Typography>
                    <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.5 }}>
                      {fortalezas.map((h) => (
                        <Tooltip key={h.nombre} title={h.evidencia ?? `Nivel ${h.nivel}/5`}>
                          <Chip
                            size="small"
                            label={`${h.nombre} · ${h.nivel}`}
                            sx={{ bgcolor: 'primary.main', color: 'primary.contrastText' }}
                          />
                        </Tooltip>
                      ))}
                    </Box>
                  </Box>
                )}

                {otras.length > 0 && (
                  <Box sx={{ mt: 1.25 }}>
                    <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                      {otras.map((h) => (
                        <Chip key={h.nombre} size="small" variant="outlined"
                              label={`${h.nombre} · ${h.nivel}`} />
                      ))}
                    </Box>
                  </Box>
                )}

                {(aportes.length > 0 || preguntas.length > 0) && <Divider sx={{ my: 1.5 }} />}

                {aportes.map((i, k) => (
                  <Box key={k} sx={{ mb: 1 }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: 'secondary.main' }}>
                      {ICONO_INSUMO[i.tipo]}
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>{i.titulo}</Typography>
                    {i.detalle && (
                      <Typography variant="caption" color="text.secondary">{i.detalle}</Typography>
                    )}
                  </Box>
                ))}

                {preguntas.length > 0 && (
                  <Box sx={{ mt: 1, p: 1.25, borderRadius: 2, bgcolor: 'background.sutil' }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }}>
                      QUÉ PREGUNTARLE
                    </Typography>
                    {preguntas.map((q, k) => (
                      <Box key={k} sx={{ mt: 0.5 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>«{q.titulo}»</Typography>
                        {q.detalle && (
                          <Typography variant="caption" color="text.secondary">{q.detalle}</Typography>
                        )}
                      </Box>
                    ))}
                  </Box>
                )}
              </CardContent>
            </Card>
          );
        })}
      </Box>
    </Stack>
  );
}
