import { Box, Stack, Typography } from '@mui/material';
import TarjetaProyecto from '@/components/TarjetaProyecto';
import { resumenProyectos } from '@/lib/consultas';
import { calcularSalud } from '@/lib/formato';

export const dynamic = 'force-dynamic';

export default async function Proyectos() {
  const proyectos = await resumenProyectos();

  return (
    <Stack spacing={2.5}>
      <Box>
        <Typography variant="h2">Proyectos</Typography>
        <Typography color="text.secondary" variant="body2">
          {proyectos.length} proyectos en el portafolio
        </Typography>
      </Box>
      <Box sx={{
        display: 'grid', gap: 2,
        gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
      }}>
        {proyectos.map((p) => (
          <TarjetaProyecto key={p.id} p={p}
                           salud={p.salud === 'sin_datos' ? calcularSalud(p) : p.salud} />
        ))}
      </Box>
    </Stack>
  );
}
