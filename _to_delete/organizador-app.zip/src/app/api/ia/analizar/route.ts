import { NextResponse } from 'next/server';
import { analizarSaludProyecto } from '@/lib/ai/cliente';
import { ProyectoNoEncontrado } from '@/lib/ai/errores';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function POST(req: Request) {
  let cuerpo: { proyecto_id?: number; forzar?: boolean };
  try {
    cuerpo = await req.json();
  } catch {
    return NextResponse.json({ error: 'Cuerpo JSON inválido' }, { status: 400 });
  }

  const proyectoId = Number(cuerpo.proyecto_id);
  if (!Number.isInteger(proyectoId) || proyectoId <= 0) {
    return NextResponse.json({ error: 'proyecto_id es obligatorio y debe ser un entero' }, { status: 400 });
  }

  try {
    const r = await analizarSaludProyecto(proyectoId, { forzar: Boolean(cuerpo.forzar) });
    return NextResponse.json(r);
  } catch (e) {
    if (e instanceof ProyectoNoEncontrado) {
      return NextResponse.json({ error: e.message }, { status: 404 });
    }
    const mensaje = e instanceof Error ? e.message : 'Error desconocido';
    console.error('[ia/analizar]', mensaje);
    return NextResponse.json({ error: mensaje }, { status: 500 });
  }
}
